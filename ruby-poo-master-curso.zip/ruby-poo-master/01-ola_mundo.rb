puts "Olá Mundo!"
puts "#{1 + 2}"
