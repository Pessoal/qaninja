v1 = 'jackson'
puts "Hello!" + v1

v2 = "jackson pires"
puts "Beleza? #{v2}"

puts "A soma de 1 + 2 é: #{1 + 2}"
