module A
  def a1
    puts "a1"
  end
  def a2
    puts "a2"
  end
end
