module B
  def b1
    puts "b1"
  end
  def b2
    puts "b2"
  end
end
