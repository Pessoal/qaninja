require_relative 'exemplo'

x = Exemplo.new

# Módulo A
x.a1
x.a2

# Módulo B
x.b1
x.b2

# Classe Exemplo
x.ex1

