require 'lerolero_generator'

puts LeroleroGenerator.paragraph
