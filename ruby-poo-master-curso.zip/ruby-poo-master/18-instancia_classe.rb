class Teste
  def ola # Método de Instância
    "Olá!"
  end

  def self.hello # Método de Classe
    "Hello!"
  end
end

#obj = Teste.new
#puts obj.ola

puts Teste.hello
