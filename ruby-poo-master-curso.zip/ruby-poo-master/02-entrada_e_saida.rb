
puts "Olá!"
puts "Digite o seu nome:"
v1 = gets.chomp # Essa linha serve para ler a entrada do teclado.
puts "O seu nome é " + v1

puts "Digite sua idade:"
v2 = gets.chomp
puts "Sua idade é: " + v2
