i = 1

while i <= 50 # enquanto for verdadeiro
  puts "jackson - #{i}"
  i += 1
end

# i == 50

until i <= 0 # enquanto for falso
  puts "sou falso - #{i}"
  i -= 1
end

puts "fim!"
