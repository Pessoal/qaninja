a = 2
a += 4 # a = a + 4
a -= 4 # a = a - 4
a *= 4 # a = a * 4
a /= 4 # a = a / 4
a %= 4 # a = a % 4
a **= 4 # a = a ** 4
puts a
