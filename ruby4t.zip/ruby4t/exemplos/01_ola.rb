
puts 'Qual o seu nome?'
nome = STDIN.gets

puts "Olá, #{nome} seja bem vindo ao mundo de Ruby pela QA Ninja."


# TIPAGEM => tipos dos Objetos (variáveis, metodos, classes, atributos)
# => Em Ruby tudo é no final das contas é um objeto

# Java/C#

# string nome = "Fernando";
# int idade = 34;
# bool bonito = true;

# Ruby
# O tipo da variável é definido no momento em que o mesmo recebe o valor

# nome = 'Fernando'
# idade = 34
# bonito = true

# puts nome
# puts nome.class

# puts idade
# puts idade.class

# idade = 'Trinta e Quantro'
# puts idade.class