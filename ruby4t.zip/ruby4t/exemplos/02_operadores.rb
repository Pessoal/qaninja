

numero1 = 0
numero2 = 0
total = 0

puts 'Informe o valor do número 1'
numero1 = STDIN.gets.to_f

puts 'Informe o valor do número 2'
numero2 = STDIN.gets.to_f

total = numero1 / numero2

puts 'O resultado da divisão é:'
puts total